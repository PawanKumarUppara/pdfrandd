package com.pdf.generate.util;

import java.io.FileOutputStream;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class PdfForm {
	public static void main(String[] args) {
		Document document = new Document();
		try
		{
		        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("Pdf_Form.pdf"));
		        document.open();
		 
		        /*PdfContentByte canvas = writer.getDirectContent();
		        Rectangle rect = new Rectangle(36, 36, 558, 806);
		        rect.setBorder(Rectangle.BOX);
		        rect.setBorderWidth(3);
		        canvas.rectangle(rect);
		        ColumnText ct = new ColumnText(canvas);
		        ct.setSimpleColumn(36, 36, 559, 806);
		        Font font1 = new Font(FontFamily.TIMES_ROMAN, 10, Font.NORMAL, BaseColor.BLACK);
		        font1.setSize(10f);*/
		      /*  PdfPTable table = new PdfPTable(1);
		        table.setWidthPercentage(98);
		        
		       // float[] columnWidths = {5f};
		        //table.setWidths(columnWidths);
		        PdfPCell cell1 = new PdfPCell();
		        cell1.setBackgroundColor(BaseColor.ORANGE);
		        cell1.setBorder(0);
		        table.addCell(cell1);
		        table.setSpacingBefore(1.5f);*/
		       /* Chunk c = new Chunk("This is the text added in the rectangle", font1);
		        c.setBackground(BaseColor.ORANGE);
		        Paragraph p = new Paragraph(c);*/
		       /* ct.addElement(new Paragraph());
		        ct.addElement(table);
		        ct.go();*/
		        PdfPTable table = new PdfPTable(1);
		        table.setWidthPercentage(100);
		        
		       // float[] columnWidths = {5f};
		        //table.setWidths(columnWidths);
		        PdfPCell cell1 = new PdfPCell();
		        cell1.setBackgroundColor(BaseColor.ORANGE);
		        Font font1 = new Font(FontFamily.TIMES_ROMAN, 5, Font.BOLD, BaseColor.BLACK);
		        font1.setSize(10f);
		        Font font2 = new Font(FontFamily.TIMES_ROMAN, 5, Font.NORMAL, BaseColor.BLACK);
		        font2.setSize(10f);
		        Paragraph p1= new Paragraph("asjdhkjahdjkhajkdhasjkhdjkashdjkhasjkdhajshdjkahsdjkhasjdh",font1);
		        p1.setAlignment(Element.ALIGN_CENTER);
		        Paragraph p2= new Paragraph("asjdhkjahdjkhajkdhasjkhdjkashdjkhasjkdhajshdjkahsdjkhasjdh",font2);
		        p2.setAlignment(Element.ALIGN_CENTER);
		        cell1.addElement(p1);
		        cell1.addElement(p2);
		        table.addCell(cell1);
		        document.add(table);
		        table = new PdfPTable(1);
		        table.setWidthPercentage(100);
		        PdfPCell cell2 = new PdfPCell();
		        cell2.setBackgroundColor(BaseColor.ORANGE);
		        //table.setSpacingBefore(1.5f);
		        BaseFont base = BaseFont.createFont("wingding.ttf", BaseFont.IDENTITY_H, false);
		        Font font3 = new Font(base, 16f, Font.BOLD);
		        char checked='\u00FE';
		        char unchecked='\u00A8';
		         p1= new Paragraph(String.valueOf(unchecked),font3);
		        p1.setAlignment(Element.ALIGN_CENTER);
		       p2= new Paragraph("asjdhkjahdjkhajkdhasjkhdjkashdjkhasjkdhajshdjkahsdjkhasjdh",font2);
		        p2.setAlignment(Element.ALIGN_CENTER);
		        cell2.addElement(p1);
		        cell2.addElement(p2);
		        table.addCell(cell2);
		        document.add(table);
		        document.close();
		
		}
		catch(Exception ex)
		{
			
		}
		
	}
	 

}
